/* 
 * Copyright (c) 2003,2004  Daniel Bryan
 * All rights reserved.
 *
 * For more information see COPYRIGHT.
 */

int pathdadd(char *master,char *dir);
int pathchsize(char *path, char *path2);
int pathnamed(char *path);
char *pathname(char *path);
int pathlong(char *path, char *path2);
